package com.example.exemplosimplesdecompose.data

data class Coordenadas(
val latitude: Double,
val longitude: Double
)
